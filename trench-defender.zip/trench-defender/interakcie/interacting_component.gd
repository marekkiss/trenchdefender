extends Node2D

@onready var interact_label: Label = $interactLabel
var current_interactions: Array = []
var can_interact: bool = true

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("interact") and can_interact and current_interactions.size() > 0:
		can_interact = false
		interact_label.hide()

		var nearest = current_interactions[0]
		await nearest.interact.call(get_parent())

		can_interact = true


func _process(_delta: float) -> void:
	if current_interactions.size() == 0 or not can_interact:
		interact_label.hide()
		return

	current_interactions.sort_custom(_sort_by_nearest)
	var nearest = current_interactions[0]

	if nearest.has_method("player_inside") and nearest.player_inside:
		interact_label.hide()
		return

	if nearest.interactable:
		interact_label.text = nearest.interact_name
		interact_label.show()
	else:
		interact_label.hide()


func _sort_by_nearest(a, b) -> bool:
	return global_position.distance_to(a.global_position) < global_position.distance_to(b.global_position)


func _on_interact_range_area_entered(area: Area2D) -> void:
	current_interactions.push_back(area)


func _on_interact_range_area_exited(area: Area2D) -> void:
	current_interactions.erase(area)
