extends Camera2D

@export var turret_offset_y: float = -100
@export var smooth_speed: float = 5.0

var base_position: Vector2

func _ready():
	base_position = position

func _process(delta):
	if not get_parent():
		return
	
	var player = get_parent()
	var target_position = base_position
	if player.using_turret:
		target_position.y += turret_offset_y
	
	position = position.lerp(target_position, delta * smooth_speed)
