extends CanvasLayer

@onready var fade_rect: ColorRect = $ColorRect
@onready var label: Label = $Label
@onready var label2: Label = $Label2

var fade_speed := 1.5

func play_sleep_transition():
	fade_rect.visible = true
	label.visible = true
	label2.visible = true

	fade_rect.modulate.a = 0.0
	label.modulate.a = 0.0
	label2.modulate.a = 0.0

	await fade_to(1.0)

	GameState.add_day()

	await get_tree().create_timer(0.8).timeout

	await fade_to(0.0)

	queue_free()


func fade_to(target_alpha: float) -> void:
	while abs(fade_rect.modulate.a - target_alpha) > 0.02:
		fade_rect.modulate.a = lerp(
			fade_rect.modulate.a,
			target_alpha,
			get_process_delta_time() * fade_speed
		)
		label.modulate.a = fade_rect.modulate.a
		label2.modulate.a = fade_rect.modulate.a
		await get_tree().process_frame
