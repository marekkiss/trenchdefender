extends CanvasLayer

@onready var fade_rect: ColorRect = $ColorRect
@onready var label: Label = $Label
@onready var label2: Label = $Label2

var fade_speed := 3.0

func play_sleep_transition():
	fade_rect.visible = true
	label.visible = true
	label2.visible = true

	fade_rect.modulate.a = 0.0
	label.modulate.a = 0.0
	label2.modulate.a = 0.0

	await fade_to(1.0)

	GameState.add_day()

	label.visible = false
	label2.visible = false

	var upgrade_ui = preload("res://UpgradeChoice.tscn").instantiate()
	upgrade_ui.layer = 100
	get_tree().current_scene.add_child(upgrade_ui)

	await upgrade_ui.tree_exited

	await fade_to(0.0)

	queue_free()


func fade_to(target_alpha: float) -> void:
	while abs(fade_rect.modulate.a - target_alpha) > 0.02:
		fade_rect.modulate.a = lerp(
			fade_rect.modulate.a,
			target_alpha,
			get_process_delta_time() * fade_speed
		)
		label.modulate.a = fade_rect.modulate.a
		label2.modulate.a = fade_rect.modulate.a
		await get_tree().process_frame
