extends Area2D
class_name Trench

@export var max_health: int = 100
@export var damage_per_enemy: int = 10
var current_health: int = 100

signal health_changed(new_health)

func _ready():
	reset_health()
	GameState.day_changed.connect(_on_day_changed)

func _on_day_changed(_day: int):
	reset_health()

func reset_health():
	current_health = max_health
	emit_signal("health_changed", current_health)

func _on_body_entered(body: Node) -> void:
	if body.has_method("on_enter_trench"):
		body.on_enter_trench()
		apply_damage(damage_per_enemy)

func apply_damage(amount: int):
	current_health = max(current_health - amount, 0)
	emit_signal("health_changed", current_health)
	if current_health <= 0:
		GameState.trigger_game_over()
