extends Node2D

@export var enemy_scene: PackedScene
@export var spawn_interval: float = 2.0

@onready var spawn_points := $SpawnPoints.get_children()
@onready var timer := $Timer

func _ready():
	timer.wait_time = spawn_interval
	timer.start()

func _on_Timer_timeout():
	spawn_enemy()

func spawn_enemy():
	if enemy_scene == null:
		return

	var spawn_point = spawn_points.pick_random()
	var enemy = enemy_scene.instantiate()

	get_tree().current_scene.add_child(enemy)
	enemy.global_position = spawn_point.global_position
