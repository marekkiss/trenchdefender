extends Control

@onready var continue_button: Button = $VBoxContainer/Button3

func _ready() -> void:
	# Show or hide the Continue button depending on whether a save exists
	if FileAccess.file_exists("user://savegame.save"):
		continue_button.visible = true
	else:
		continue_button.visible = false


func _on_start_pressed() -> void:
	GameState.start_new_game()
	SceneTransition.change_scene("res://world.tscn")


func _on_continue_pressed() -> void:
	GameState.load_game()
	SceneTransition.change_scene("res://world.tscn")


func _on_exit_pressed() -> void:
	get_tree().quit()
