extends Control

@onready var continue_button: Button = $VBoxContainer/Button3

func _ready() -> void:
	if FileAccess.file_exists("user://savegame.save"):
		continue_button.visible = true
	else:
		continue_button.visible = false


func _on_start_pressed() -> void:
	GameState.start_new_game()
	SceneTransition.change_scene("res://world.tscn")


func _on_continue_pressed() -> void:
	GameState.load_game()
	SceneTransition.change_scene("res://world.tscn")


func _on_exit_pressed() -> void:
	get_tree().quit()


func _on_settings_pressed() -> void:
	var settings = preload("res://SettingsMenu.tscn").instantiate()
	add_child(settings)
