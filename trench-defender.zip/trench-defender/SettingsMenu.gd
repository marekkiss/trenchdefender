extends CanvasLayer

@onready var master_volume: HSlider = $Panel/VBoxContainer/HBoxContainer/MasterVolumeSlider
@onready var mute_checkbox: CheckBox = $Panel/VBoxContainer/MuteCheck
@onready var windowed_checkbox: CheckBox = $Panel/VBoxContainer/WindowedCheck
@onready var resolution_option: OptionButton = $Panel/VBoxContainer/HBoxContainer2/ResolutionOption
@onready var back_button: Button = $Panel/VBoxContainer/BackButton

const SAVE_PATH := "user://settings.save"
const MASTER_BUS := "Master"

var loading := true
var previous_pause_menu: CanvasLayer = null


func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().paused = true

	_populate_resolutions()

	master_volume.value_changed.connect(_on_master_volume_changed)
	mute_checkbox.toggled.connect(_on_mute_toggled)
	windowed_checkbox.toggled.connect(_on_windowed_toggled)
	resolution_option.item_selected.connect(_on_resolution_selected)
	back_button.pressed.connect(_on_back_pressed)

	_load_settings()
	loading = false



func _on_master_volume_changed(value):
	if loading:
		return
	var bus := AudioServer.get_bus_index(MASTER_BUS)
	AudioServer.set_bus_volume_db(bus, value)


func _on_mute_toggled(pressed):
	if loading:
		return
	var bus := AudioServer.get_bus_index(MASTER_BUS)
	AudioServer.set_bus_mute(bus, pressed)



func _on_windowed_toggled(pressed):
	if pressed:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)

	var res = resolution_option.get_item_metadata(resolution_option.selected)
	if res:
		DisplayServer.window_set_size(res)


func _on_resolution_selected(index):
	var res = resolution_option.get_item_metadata(index)
	if not res:
		return

	if windowed_checkbox.button_pressed:
		DisplayServer.window_set_size(res)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		DisplayServer.window_set_size(res)
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)


func _on_back_pressed():
	_save_settings()

	get_tree().paused = false
	if previous_pause_menu:
		previous_pause_menu.visible = true

	queue_free()


func _populate_resolutions():
	resolution_option.clear()
	var res_list = [
		{"name": "1024x576", "size": Vector2(1024, 576)},
		{"name": "1280x720", "size": Vector2(1280, 720)},
		{"name": "1600x900", "size": Vector2(1600, 900)}
	]
	for r in res_list:
		resolution_option.add_item(r.name)
		resolution_option.set_item_metadata(
			resolution_option.get_item_count() - 1,
			r.size
		)

func _save_settings():
	var bus := AudioServer.get_bus_index(MASTER_BUS)
	var data = {
		"volume_db": AudioServer.get_bus_volume_db(bus),
		"mute": AudioServer.is_bus_mute(bus),
		"windowed": windowed_checkbox.button_pressed,
		"resolution_index": resolution_option.selected
	}

	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	file.store_var(data)
	file.close()


func _load_settings():
	if not FileAccess.file_exists(SAVE_PATH):
		return

	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	var data = file.get_var()
	file.close()

	var bus := AudioServer.get_bus_index(MASTER_BUS)

	if data.has("volume_db"):
		AudioServer.set_bus_volume_db(bus, data.volume_db)
		master_volume.set_value_no_signal(data.volume_db)

	if data.has("mute"):
		AudioServer.set_bus_mute(bus, data.mute)
		mute_checkbox.set_pressed_no_signal(data.mute)

	if data.has("windowed"):
		windowed_checkbox.set_pressed_no_signal(data.windowed)
		_on_windowed_toggled(data.windowed)

	if data.has("resolution_index"):
		resolution_option.select(data.resolution_index)
