extends Node2D

@onready var trench: Node = $Trench
@onready var shelling = $DistantShelling

func _ready():
	SceneTransition.fade_in()
	GameState.wave_started.connect(_on_wave_started)
	GameState.wave_ended.connect(_on_wave_ended)
	
	if not GameState.wave_active:
		shelling.play()
	
	if trench:
		trench.current_health = trench.max_health
		trench.emit_signal("health_changed", trench.current_health)

	GameState.reset_wave_state()
	
func _on_wave_started():
	shelling.stop()

func _on_wave_ended():
	shelling.play()
