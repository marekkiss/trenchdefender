extends CharacterBody2D
class_name Player

@export var move_speed: float = 50.0
var direction: Vector2 = Vector2.ZERO
var cardinal_direction: Vector2 = Vector2.DOWN
var movement_enabled: bool = true
var using_turret: bool = false

@onready var animation_player: AnimationPlayer = $AnimationPlayer

func _physics_process(_delta):
	if movement_enabled:
		direction.x = Input.get_action_strength("right") - Input.get_action_strength("left")
		direction.y = Input.get_action_strength("down") - Input.get_action_strength("up")
		
		if direction.x != 0:
			direction.y = 0
		
		velocity = direction * move_speed
		move_and_slide()
		
		if direction != Vector2.ZERO:
			if direction.x > 0:
				cardinal_direction = Vector2.RIGHT
			elif direction.x < 0:
				cardinal_direction = Vector2.LEFT
			elif direction.y > 0:
				cardinal_direction = Vector2.DOWN
			elif direction.y < 0:
				cardinal_direction = Vector2.UP
	else:
		velocity = Vector2.ZERO
	
	UpdateAnimation()

func UpdateAnimation():
	var anim_name: String = ""
	
	if direction == Vector2.ZERO:
		anim_name = "idle"
	elif cardinal_direction == Vector2.UP:
		anim_name = "walk_up"
	elif cardinal_direction == Vector2.DOWN:
		anim_name = "walk_down"
	elif cardinal_direction == Vector2.LEFT:
		anim_name = "walk_left"
	elif cardinal_direction == Vector2.RIGHT:
		anim_name = "walk_right"
	
	if animation_player.current_animation != anim_name:
		animation_player.play(anim_name)
	
	if using_turret:
		if animation_player.current_animation != "turret":
			animation_player.play("turret")
		return
