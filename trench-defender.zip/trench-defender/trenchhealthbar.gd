extends TextureProgressBar

@export var trench: Trench

func _ready():
	if trench == null:
		return
	
	if not trench.is_connected("health_changed", Callable(self, "_on_health_changed")):
		trench.connect("health_changed", Callable(self, "_on_health_changed"))

	_on_health_changed(trench.current_health)


func _on_health_changed(new_health: int):
	value = float(new_health) / float(trench.max_health) * 100.0
