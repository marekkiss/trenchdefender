extends Area2D

@export var speed: float = 400
@export var damage: int = 1

var direction: Vector2 = Vector2.ZERO

@onready var sprite: Sprite2D = $Sprite2D

func _ready():
	connect("body_entered", Callable(self, "_on_body_entered"))

func _process(delta):
	if direction == Vector2.ZERO:
		return
	
	position += direction * speed * delta
	
	rotation = direction.angle()

func _on_body_entered(body):
	if body.has_method("take_damage"):
		body.take_damage(damage)
	queue_free()
