extends Node

var current_day: int = 1
var trench_health: int = 100

func next_day():
	current_day += 1
	trench_health = 100
