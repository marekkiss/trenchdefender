extends Node

signal day_changed(day: int)
signal wave_started
signal wave_ended
signal game_over

var current_day: int = 1
var save_file_path := "user://savegame.save"

var wave_active: bool = false
var wave_finished: bool = false
var enemies_spawned: int = 0
var enemies_alive: int = 0
var enemies_per_wave: int = 20

func start_new_game():
	current_day = 1
	reset_wave_state()
	save_game()
	emit_signal("day_changed", current_day)

func add_day():
	current_day += 1
	reset_wave_state()
	save_game()
	emit_signal("day_changed", current_day)
	wave_finished = false

func save_game():
	var file = FileAccess.open(save_file_path, FileAccess.WRITE)
	if file:
		file.store_var({"day": current_day})
		file.close()

func load_game():
	if FileAccess.file_exists(save_file_path):
		var file = FileAccess.open(save_file_path, FileAccess.READ)
		if file:
			var data = file.get_var()
			current_day = data.get("day", 1)
			file.close()
	else:
		current_day = 1
	reset_wave_state()
	emit_signal("day_changed", current_day)

func start_wave():
	if wave_active:
		return

	enemies_per_wave = get_enemies_per_wave()
	wave_finished = false
	wave_active = true
	enemies_spawned = 0
	enemies_alive = 0
	emit_signal("wave_started")

func register_enemy_spawned():
	enemies_spawned += 1
	enemies_alive += 1

func register_enemy_removed():
	enemies_alive -= 1
	_check_wave_finished()

func _check_wave_finished():
	if enemies_alive <= 0 and enemies_spawned >= enemies_per_wave:
		end_wave()

func end_wave():
	if not wave_active:
		return
	wave_active = false
	wave_finished = true
	emit_signal("wave_ended")

func reset_wave_state():
	wave_active = false
	wave_finished = false
	enemies_spawned = 0
	enemies_alive = 0

func trigger_game_over():
	if get_tree().paused:
		return
	var dir := DirAccess.open("user://")
	if dir != null and dir.file_exists("savegame.save"):
		dir.remove("savegame.save")
	emit_signal("game_over")
	var game_over_ui = preload("res://GameOver.tscn").instantiate()
	get_tree().current_scene.add_child(game_over_ui)
	
func get_enemies_per_wave() -> int:
	return 20 + (current_day - 1) * 5
