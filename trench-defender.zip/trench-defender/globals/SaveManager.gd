extends Node

const SAVE_PATH := "user://savegame.save"

func save_game():
	var data = {
		"day": GameState.current_day
	}

	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	file.store_var(data)
	file.close()

	print("Game saved")

func load_game():
	if not FileAccess.file_exists(SAVE_PATH):
		print("No save found")
		return false

	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	var data = file.get_var()
	file.close()

	GameState.current_day = data["day"]
	print("Game loaded, day:", GameState.current_day)
	return true
