extends CanvasLayer

@onready var rect: ColorRect = $ColorRect
var is_transitioning := false


func _ready():
	rect.color.a = 0.0
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE


func change_scene(path: String):
	if is_transitioning:
		return

	is_transitioning = true

	var tween = create_tween()
	tween.tween_property(rect, "color:a", 1.0, 0.5)
	tween.tween_callback(func():
		get_tree().change_scene_to_file(path)
	)
	tween.tween_property(rect, "color:a", 0.0, 0.5)
	tween.tween_callback(func():
		is_transitioning = false
	)


func fade_in():
	rect.color.a = 1.0

	var tween = create_tween()
	tween.tween_property(rect, "color:a", 0.0, 0.5)
