extends Node2D

@onready var interactable: Area2D = $interactable
@onready var gun_pivot: Node2D = $GunPivot
@onready var muzzle: Marker2D = $GunPivot/Marker2D
@onready var hint_label: Label = $HintLabel
@onready var charge_sound = $AudioCharge
@onready var snd_fire_start = $AudioFireStart
@onready var snd_fire_loop = $AudioFireLoop
@onready var snd_fire_end = $AudioFireEnd

var is_firing := false
var player_inside := false
var player_ref: Player = null

const BULLET = preload("res://bullet/bullet.tscn")
var FIRE_RATE := 0.45
var time_since_last_shot := 0.0

func _ready() -> void:
	GameState.wave_started.connect(_on_wave_started)
	GameState.wave_ended.connect(_on_wave_ended)
	
	interactable.interact = Callable(self, "_on_interact")
	hint_label.visible = false

func _on_interact(player):
	player_inside = !player_inside

	if player_inside:
		player_ref = player
		player_ref.movement_enabled = false
		player_ref.using_turret = true
		interactable.interactable = false
		_update_hint()
	else:
		_stop_firing()
		player_ref.movement_enabled = true
		player_ref.using_turret = false
		player_ref = null
		interactable.interactable = true
		hint_label.visible = false


func _process(delta):
	if not player_inside:
		return

	# Aim
	var target_pos = get_global_mouse_position()
	var desired_angle = (target_pos - gun_pivot.global_position).angle()
	gun_pivot.rotation = lerp_angle(gun_pivot.rotation, desired_angle, delta * 8)

	time_since_last_shot += delta

	# START firing
	if player_inside and Input.is_action_just_pressed("shoot"):
		_start_firing()

	# STOP firing
	if Input.is_action_just_released("shoot"):
		_stop_firing()

	# Fire bullets
	if player_inside and is_firing and time_since_last_shot >= FIRE_RATE:
		_fire_bullet()
		time_since_last_shot = 0.0

	# Start wave
	if not GameState.wave_active and Input.is_action_just_pressed("ui_accept") and not GameState.wave_finished:
		GameState.start_wave()

func _fire_bullet():
	var bullet = BULLET.instantiate()
	get_tree().current_scene.add_child(bullet)
	bullet.global_position = muzzle.global_position
	bullet.direction = (get_global_mouse_position() - muzzle.global_position).normalized()

func _update_hint():
	hint_label.visible = player_inside and not GameState.wave_active and not GameState.wave_finished
	hint_label.text = "Press SPACE to start wave"

func _on_wave_started():
	hint_label.visible = false
	charge_sound.play()

func _on_wave_ended():
	hint_label.visible = false
	charge_sound.stop()
	_stop_firing()
	
func _start_firing():
	if is_firing:
		return

	is_firing = true
	snd_fire_start.play()
	snd_fire_loop.play()
	
func _stop_firing():
	if not is_firing:
		return

	is_firing = false
	snd_fire_loop.stop()
	snd_fire_end.play()
