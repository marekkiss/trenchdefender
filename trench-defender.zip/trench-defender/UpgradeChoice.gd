extends CanvasLayer

@onready var panel: VBoxContainer = $VBoxContainer
@onready var button_left: Button = $VBoxContainer/ButtonLeft
@onready var button_right: Button = $VBoxContainer/ButtonRight

var fade_speed := 3.0

const UPGRADE_DATA := {
	"fire_rate": { "title": "+10% Fire rate" },
	"trench_health": { "title": "+10% Trench health" },
	"enemy_speed": { "title": "-10% Enemy speed" },
	"spawn_interval": { "title": "-10% Enemy spawn rate" }
}

func _ready():
	panel.modulate.a = 0.0
	_disable_buttons()

	var keys: Array = UPGRADE_DATA.keys()
	var left = keys.pick_random()
	keys.erase(left)
	var right = keys.pick_random()

	button_left.text = UPGRADE_DATA[left]["title"]
	button_right.text = UPGRADE_DATA[right]["title"]

	button_left.set_meta("upgrade_type", left)
	button_right.set_meta("upgrade_type", right)

	button_left.pressed.connect(_on_pressed.bind(button_left))
	button_right.pressed.connect(_on_pressed.bind(button_right))

	await _fade_panel_to(1.0)
	_enable_buttons()


func _on_pressed(button: Button):
	_disable_buttons()

	var upgrade_type: String = button.get_meta("upgrade_type")
	_apply_upgrade(upgrade_type)
	GameState.save_game()

	await _fade_panel_to(0.0)
	queue_free()


func _fade_panel_to(target: float):
	while abs(panel.modulate.a - target) > 0.02:
		panel.modulate.a = lerp(
			panel.modulate.a,
			target,
			get_process_delta_time() * fade_speed
		)
		await get_tree().process_frame


func _disable_buttons():
	button_left.disabled = true
	button_right.disabled = true


func _enable_buttons():
	button_left.disabled = false
	button_right.disabled = false


func _apply_upgrade(upgrade_type: String):
	match upgrade_type:
		"fire_rate":
			var machine_gun = get_tree().current_scene.get_node_or_null("machinegun")
			if machine_gun:
				machine_gun.FIRE_RATE = max(machine_gun.FIRE_RATE - 0.045, 0.05)


		"trench_health":
			var trench = get_tree().current_scene.get_node_or_null("Trench")
			if trench:
				trench.max_health += 10
				trench.current_health = trench.max_health

		"enemy_speed":
			GameState.enemy_speed_multiplier *= 0.9
			for enemy in get_tree().get_nodes_in_group("enemies"):
				enemy.move_speed *= 0.9


		"spawn_interval":
			var spawner = get_tree().current_scene.get_node_or_null("EnemySpawner")
			if spawner:
				spawner.spawn_interval *= 1.1
				spawner.get_node("Timer").wait_time = spawner.spawn_interval
