extends CanvasLayer

@onready var bg: ColorRect = $ColorRect
@onready var resume_button = $VBoxContainer/Button
@onready var settings_button = $VBoxContainer/SettingsButton
@onready var quit_button = $VBoxContainer/Button2

var is_open := false

func _ready():
	hide()
	bg.color.a = 0.0
	process_mode = Node.PROCESS_MODE_ALWAYS

	resume_button.pressed.connect(_on_resume_pressed)
	settings_button.pressed.connect(_on_settings_pressed)
	quit_button.pressed.connect(_on_quit_pressed)

func _unhandled_input(event):
	if event.is_action_pressed("pause"):
		toggle()

func toggle():
	if is_open:
		close()
	else:
		open()

func open():
	is_open = true
	show()
	get_tree().paused = true

	var tween = create_tween()
	tween.tween_property(bg, "color:a", 0.8, 0.25)

func close():
	is_open = false

	var tween = create_tween()
	tween.tween_property(bg, "color:a", 0.0, 0.25)
	tween.tween_callback(func():
		hide()
		get_tree().paused = false
	)

func _on_resume_pressed():
	close()

func _on_quit_pressed():
	get_tree().paused = false
	SceneTransition.change_scene("res://main_menu.tscn")

func _on_settings_pressed():
	visible = false

	var settings = preload("res://SettingsMenu.tscn").instantiate()
	settings.previous_pause_menu = self
	get_tree().current_scene.add_child(settings)
