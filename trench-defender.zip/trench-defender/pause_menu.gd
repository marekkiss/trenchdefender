extends CanvasLayer

@onready var bg: ColorRect = $ColorRect

var is_open := false


func _ready():
	hide()
	bg.color.a = 0.0
	process_mode = Node.PROCESS_MODE_ALWAYS


func _unhandled_input(event):
	if event.is_action_pressed("pause"):
		toggle()


func toggle():
	if is_open:
		close()
	else:
		open()


func open():
	is_open = true
	show()
	get_tree().paused = true

	var tween = create_tween()
	tween.tween_property(bg, "color:a", 0.8, 0.25)


func close():
	var tween = create_tween()
	tween.tween_property(bg, "color:a", 0.0, 0.25)
	tween.tween_callback(func():
		hide()
		get_tree().paused = false
		is_open = false
	)


func _on_resume_pressed():
	close()


func _on_quit_pressed():
	get_tree().paused = false
	SceneTransition.change_scene("res://main_menu.tscn")
