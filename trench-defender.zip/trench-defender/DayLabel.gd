extends Label

func _ready():
	update_day(GameState.current_day)
	GameState.day_changed.connect(update_day)

func update_day(day: int):
	text = "Day: " + str(day)
