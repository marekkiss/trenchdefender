extends Area2D

@onready var interactable: Node = $interactable

func _ready():
	interactable.interact = Callable(self, "_on_interact")

	_update_interact_text()

	GameState.wave_started.connect(_update_interact_text)
	GameState.wave_ended.connect(_update_interact_text)
	GameState.day_changed.connect(_update_interact_text)

func _update_interact_text(_day = null):
	if GameState.wave_finished:
		interactable.interact_name = "Press E to sleep"
	else:
		interactable.interact_name = "You must finish the wave first!"

func _on_interact(_player):
	if not GameState.wave_finished:
		return

	var sleep_scene = preload("res://sleep_transition.tscn").instantiate()
	get_tree().current_scene.add_child(sleep_scene)
	sleep_scene.play_sleep_transition()
