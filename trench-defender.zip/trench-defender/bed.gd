extends Area2D

@onready var interactable: Node = $interactable

func _ready():
	interactable.interact = Callable(self, "_on_interact")

	# Update text immediately
	_update_interact_text()

	# Update text on relevant signals
	GameState.connect("wave_started", Callable(self, "_update_interact_text"))
	GameState.connect("wave_ended", Callable(self, "_update_interact_text"))
	GameState.connect("day_changed", Callable(self, "_update_interact_text"))

func _update_interact_text(_day = null):
	if GameState.wave_finished:
		interactable.interact_name = "Press E to sleep"
	else:
		interactable.interact_name = "You must finish the wave first!"

func _on_interact(_player):
	# Prevent sleeping if wave not finished
	if not GameState.wave_finished:
		return

	# Player can sleep: instantiate sleep transition
	var sleep_scene = preload("res://sleep_transition.tscn").instantiate()
	get_tree().current_scene.add_child(sleep_scene)
	sleep_scene.play_sleep_transition()
