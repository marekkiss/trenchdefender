extends Node2D

@export var enemy_scene: PackedScene
@export var spawn_interval: float = 0.85
@export var trench_node: NodePath

@onready var timer: Timer = $Timer
@onready var trench: Node2D = get_node(trench_node)

func _ready() -> void:
	timer.wait_time = spawn_interval
	timer.stop()
	GameState.wave_started.connect(_on_wave_started)
	GameState.wave_ended.connect(_on_wave_ended)


func _on_wave_started():
	timer.start()


func _on_wave_ended():
	timer.stop()


func _on_timer_timeout():
	if not GameState.wave_active:
		return

	if GameState.enemies_spawned >= GameState.enemies_per_wave:
		timer.stop()
		return

	spawn_enemy()
	GameState.register_enemy_spawned()


func spawn_enemy() -> void:
	var spawn_points = get_children().filter(func(c): return c is Marker2D)
	if spawn_points.is_empty():
		return

	var spawn_point = spawn_points.pick_random()
	var enemy = enemy_scene.instantiate()
	enemy.global_position = spawn_point.global_position

	var targets = trench.get_children().filter(func(n): return n is Marker2D)
	enemy.target_trench = targets.pick_random() if not targets.is_empty() else trench

	get_tree().current_scene.add_child(enemy)
