extends CanvasLayer

@onready var bg: ColorRect = $ColorRect

func _ready():
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().paused = true

	bg.color.a = 0.0

	var tween = create_tween()
	tween.tween_property(bg, "color:a", 1.0, 2)

func _on_button_pressed():
	get_tree().paused = false
	SceneTransition.change_scene("res://main_menu.tscn")
