extends CharacterBody2D

@export var move_speed: float = 40.0
@export var max_health: int = 2
var health: int
var target_trench: Node2D = null

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	health = max_health
	if anim:
		anim.play("attack")

func _physics_process(_delta: float) -> void:
	if target_trench == null:
		return
	var dir = (target_trench.global_position - global_position).normalized()
	velocity = dir * move_speed
	move_and_slide()

func take_damage(amount: int) -> void:
	health -= amount
	if health <= 0:
		die()

func on_enter_trench() -> void:
	GameState.register_enemy_removed()
	queue_free()
	
func die() -> void:
	GameState.register_enemy_removed()
	queue_free()
